import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataFile = path.join(__dirname, 'data.json');

const initialData = {
  residents: [
    { id: 1, nome: 'Pablo Fernandes', apartamento: '101', bloco: 'A', telefone: '(16) 99999-9999', email: 'pablo@email.com' }
  ],
  finances: [
    { id: 1, tipo: 'receita', categoria: 'Condomínio', descricao: 'Taxa mensal', valor: 3200, data: '2026-06-01' },
    { id: 2, tipo: 'despesa', categoria: 'Energia', descricao: 'Conta de luz', valor: 850, data: '2026-06-05' }
  ],
  fines: [
    { id: 1, morador: 'Apto 101', motivo: 'Barulho após horário permitido', valor: 150, status: 'pendente', data: '2026-06-10' }
  ],
  deliveries: [
    { id: 1, morador: 'Apto 101', remetente: 'Mercado Livre', codigo: 'ML123', status: 'recebida', data: '2026-06-12' }
  ],
  reservations: [
    { id: 1, morador: 'Apto 101', espaco: 'Salão de festas', data: '2026-06-20', horario: '19:00', status: 'confirmada' }
  ],
  gate: [
    { id: 1, visitante: 'João Silva', documento: '123456', apartamento: '101', tipo: 'visitante', status: 'entrada', data: '2026-06-15 14:30' }
  ],
  workOrders: [
    { id: 1, titulo: 'Trocar lâmpada', local: 'Garagem', prioridade: 'média', status: 'aberta', responsavel: 'Zelador', prazo: '2026-06-18' }
  ],
  maintenance: [
    { id: 1, titulo: 'Revisão do portão', local: 'Entrada principal', tipo: 'preventiva', status: 'agendada', custo: 300, data: '2026-06-25' }
  ]
};

function ensureData() {
  if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, JSON.stringify(initialData, null, 2));
}
function readData() { ensureData(); return JSON.parse(fs.readFileSync(dataFile, 'utf8')); }
function writeData(data) { fs.writeFileSync(dataFile, JSON.stringify(data, null, 2)); }
function nextId(items) { return items.length ? Math.max(...items.map(i => Number(i.id))) + 1 : 1; }

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());

app.get('/', (_, res) => res.json({ ok: true, message: 'API do condomínio rodando' }));

app.post('/api/login', (req, res) => {
  const { email, senha } = req.body;
  if (email === 'admin@condominio.com' && senha === '123456') {
    return res.json({ token: 'token-demo', user: { nome: 'Administrador', email, perfil: 'admin' } });
  }
  res.status(401).json({ error: 'E-mail ou senha inválidos' });
});

app.get('/api/dashboard', (_, res) => {
  const d = readData();
  const receitas = d.finances.filter(f => f.tipo === 'receita').reduce((s, f) => s + Number(f.valor || 0), 0);
  const despesas = d.finances.filter(f => f.tipo === 'despesa').reduce((s, f) => s + Number(f.valor || 0), 0);
  const multasPendentes = d.fines.filter(f => f.status !== 'paga').reduce((s, f) => s + Number(f.valor || 0), 0);
  res.json({ receitas, despesas, saldo: receitas - despesas, multasPendentes, moradores: d.residents.length, entregas: d.deliveries.length, reservas: d.reservations.length, osAbertas: d.workOrders.filter(o => o.status !== 'concluída').length, manutencoes: d.maintenance.length });
});

const resources = ['residents','finances','fines','deliveries','reservations','gate','workOrders','maintenance'];
for (const name of resources) {
  app.get(`/api/${name}`, (_, res) => res.json(readData()[name]));
  app.post(`/api/${name}`, (req, res) => {
    const data = readData();
    const item = { id: nextId(data[name]), ...req.body };
    data[name].push(item); writeData(data);
    io.emit('updated', { resource: name });
    res.status(201).json(item);
  });
  app.put(`/api/${name}/:id`, (req, res) => {
    const data = readData(); const id = Number(req.params.id);
    const idx = data[name].findIndex(i => Number(i.id) === id);
    if (idx === -1) return res.status(404).json({ error: 'Registro não encontrado' });
    data[name][idx] = { ...data[name][idx], ...req.body, id };
    writeData(data); io.emit('updated', { resource: name });
    res.json(data[name][idx]);
  });
  app.delete(`/api/${name}/:id`, (req, res) => {
    const data = readData(); const id = Number(req.params.id);
    data[name] = data[name].filter(i => Number(i.id) !== id);
    writeData(data); io.emit('updated', { resource: name });
    res.json({ ok: true });
  });
}

io.on('connection', socket => { socket.emit('connected', { ok: true }); });

const PORT = process.env.PORT || 3333;
httpServer.listen(PORT, () => console.log(`API rodando em http://localhost:${PORT}`));
