# Condomínio App - versão estável

Sistema simples e completo para rodar localmente no Windows.

## Rodar backend
```bash
cd backend
npm install
npm run dev
```
API: http://localhost:3333

## Rodar frontend
Abra outro terminal:
```bash
cd frontend
npm install
npm run dev
```
App: http://localhost:5173

## Login
E-mail: admin@condominio.com
Senha: 123456

## O que tem
- Dashboard com gráfico
- Moradores
- Financeiro
- Multas
- Portaria
- Entregas
- Reservas
- Ordens de Serviço
- Manutenção
- Adicionar, editar e excluir em tudo
- Atualização em tempo real com Socket.IO
- Responsivo para celular
- Dados salvos em backend/src/data.json
