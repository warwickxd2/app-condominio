import React, { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { api } from '../services/api.js';
import { socket } from '../services/socket.js';

export default function Dashboard(){
  const [d,setD]=useState(null);
  async function load(){ const {data}=await api.get('/dashboard'); setD(data); }
  useEffect(()=>{ load(); socket.on('updated', load); return ()=>socket.off('updated', load); },[]);
  if(!d) return <p>Carregando...</p>;
  const chart=[{nome:'Receitas',valor:d.receitas},{nome:'Despesas',valor:d.despesas},{nome:'Multas',valor:d.multasPendentes},{nome:'Saldo',valor:d.saldo}];
  return <div><h1>Dashboard</h1><div className="grid">
    <div className="stat"><span>Receitas</span><br/><b>R$ {d.receitas}</b></div><div className="stat"><span>Despesas</span><br/><b>R$ {d.despesas}</b></div><div className="stat"><span>Saldo</span><br/><b>R$ {d.saldo}</b></div><div className="stat"><span>Multas pendentes</span><br/><b>R$ {d.multasPendentes}</b></div>
    <div className="stat"><span>Moradores</span><br/><b>{d.moradores}</b></div><div className="stat"><span>Entregas</span><br/><b>{d.entregas}</b></div><div className="stat"><span>Reservas</span><br/><b>{d.reservas}</b></div><div className="stat"><span>OS abertas</span><br/><b>{d.osAbertas}</b></div>
  </div><br/><div className="card" style={{height:330}}><h2>Resumo financeiro</h2><ResponsiveContainer width="100%" height="80%"><BarChart data={chart}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="nome"/><YAxis/><Tooltip/><Bar dataKey="valor" /></BarChart></ResponsiveContainer></div></div>
}
