import React, { useEffect, useState } from 'react';
import { api } from '../services/api.js';
import { socket } from '../services/socket.js';

export default function CrudPage({config}){
  const empty=Object.fromEntries(config.fields.map(([k])=>[k,'']));
  const [items,setItems]=useState([]); const [form,setForm]=useState(empty); const [editing,setEditing]=useState(null); const [show,setShow]=useState(false); const [search,setSearch]=useState('');
  async function load(){ const {data}=await api.get('/'+config.endpoint); setItems(data); }
  useEffect(()=>{ load(); const cb=e=>{ if(e.resource===config.endpoint) load(); }; socket.on('updated',cb); return()=>socket.off('updated',cb); },[config.endpoint]);
  function change(k,v){ setForm({...form,[k]:v}); }
  async function save(e){ e.preventDefault(); if(editing) await api.put(`/${config.endpoint}/${editing}`,form); else await api.post('/'+config.endpoint,form); setShow(false); setEditing(null); setForm(empty); load(); }
  function edit(item){ setEditing(item.id); setForm({...empty,...item}); setShow(true); }
  async function del(id){ if(confirm('Tem certeza que deseja excluir?')){ await api.delete(`/${config.endpoint}/${id}`); load(); } }
  const filtered=items.filter(i=>JSON.stringify(i).toLowerCase().includes(search.toLowerCase()));
  return <div><div className="page-title"><h1>{config.title}</h1><button className="primary" onClick={()=>{setEditing(null);setForm(empty);setShow(true)}}>+ Novo</button></div><input placeholder="Pesquisar..." value={search} onChange={e=>setSearch(e.target.value)}/>{show&&<form className="card" onSubmit={save}><h2>{editing?'Editar':'Novo'} registro</h2><div className="form-grid">{config.fields.map(([k,label,type='text'])=><label key={k}>{label}<input type={type} value={form[k]??''} onChange={e=>change(k,e.target.value)} required={k!=='email'}/></label>)}</div><div className="actions"><button className="primary">Salvar</button><button type="button" className="muted" onClick={()=>setShow(false)}>Cancelar</button></div></form>}<br/><div className="table-wrap"><table className="table"><thead><tr>{config.fields.map(([k,label])=><th key={k}>{label}</th>)}<th>Ações</th></tr></thead><tbody>{filtered.map(item=><tr key={item.id}>{config.fields.map(([k])=><td key={k}>{String(item[k]??'')}</td>)}<td><div className="actions"><button className="muted" onClick={()=>edit(item)}>Editar</button><button className="danger" onClick={()=>del(item.id)}>Excluir</button></div></td></tr>)}{filtered.length===0&&<tr><td colSpan={config.fields.length+1}>Nenhum registro encontrado.</td></tr>}</tbody></table></div></div>
}
