import React, { useState } from 'react';
import { NavLink, Route, Routes, Navigate, useNavigate } from 'react-router-dom';
import { api } from './services/api.js';
import Dashboard from './pages/Dashboard.jsx';
import CrudPage from './pages/CrudPage.jsx';

const modules = [
  ['dashboard','Dashboard'], ['residents','Moradores'], ['finances','Financeiro'], ['fines','Multas'], ['gate','Portaria'], ['deliveries','Entregas'], ['reservations','Reservas'], ['workOrders','Ordens de Serviço'], ['maintenance','Manutenção']
];

const configs = {
  residents: { title:'Moradores', endpoint:'residents', fields:[['nome','Nome'],['apartamento','Apartamento'],['bloco','Bloco'],['telefone','Telefone'],['email','Email']] },
  finances: { title:'Financeiro', endpoint:'finances', fields:[['tipo','Tipo receita/despesa'],['categoria','Categoria'],['descricao','Descrição'],['valor','Valor','number'],['data','Data','date']] },
  fines: { title:'Multas', endpoint:'fines', fields:[['morador','Morador/Apto'],['motivo','Motivo'],['valor','Valor','number'],['status','Status'],['data','Data','date']] },
  gate: { title:'Portaria', endpoint:'gate', fields:[['visitante','Visitante'],['documento','Documento'],['apartamento','Apartamento'],['tipo','Tipo'],['status','Status entrada/saída'],['data','Data e hora']] },
  deliveries: { title:'Entregas', endpoint:'deliveries', fields:[['morador','Morador/Apto'],['remetente','Remetente'],['codigo','Código'],['status','Status'],['data','Data','date']] },
  reservations: { title:'Reservas', endpoint:'reservations', fields:[['morador','Morador/Apto'],['espaco','Espaço'],['data','Data','date'],['horario','Horário'],['status','Status']] },
  workOrders: { title:'Ordens de Serviço', endpoint:'workOrders', fields:[['titulo','Título'],['local','Local'],['prioridade','Prioridade'],['status','Status'],['responsavel','Responsável'],['prazo','Prazo','date']] },
  maintenance: { title:'Manutenção', endpoint:'maintenance', fields:[['titulo','Título'],['local','Local'],['tipo','Tipo'],['status','Status'],['custo','Custo','number'],['data','Data','date']] }
};

function Login(){
  const nav=useNavigate(); const [email,setEmail]=useState('admin@condominio.com'); const [senha,setSenha]=useState('123456'); const [erro,setErro]=useState('');
  async function entrar(e){e.preventDefault();try{const {data}=await api.post('/login',{email,senha});localStorage.setItem('token',data.token);nav('/dashboard')}catch{setErro('Login inválido')}}
  return <div className="login"><form className="card" onSubmit={entrar}><h1>Condomínio App</h1><p>Sistema completo de condomínio</p><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="E-mail"/><input value={senha} onChange={e=>setSenha(e.target.value)} placeholder="Senha" type="password"/><button className="primary" style={{width:'100%'}}>Entrar</button>{erro&&<p style={{color:'red'}}>{erro}</p>}<small>admin@condominio.com / 123456</small></form></div>
}
function Layout(){
 const [open,setOpen]=useState(false); const nav=useNavigate();
 const menu=<aside className={open?'sidebar open':'sidebar'}><h2>🏢 Condomínio</h2>{modules.map(([path,label])=><NavLink key={path} to={'/'+path} onClick={()=>setOpen(false)}>{label}</NavLink>)}<button className="danger" onClick={()=>{localStorage.removeItem('token');nav('/login')}}>Sair</button></aside>;
 return <div className="app">{menu}<main className="main"><div className="topbar"><button className="mobile-menu primary" onClick={()=>setOpen(!open)}>Menu</button><b>Administração do Condomínio</b></div><Routes><Route path="/dashboard" element={<Dashboard/>}/>{Object.entries(configs).map(([k,c])=><Route key={k} path={'/'+k} element={<CrudPage config={c}/>}/>) }<Route path="*" element={<Navigate to="/dashboard"/>}/></Routes></main></div>
}
function Private(){ return localStorage.getItem('token') ? <Layout/> : <Navigate to="/login"/> }
export default function App(){ return <Routes><Route path="/login" element={<Login/>}/><Route path="/*" element={<Private/>}/></Routes> }
